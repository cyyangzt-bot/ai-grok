// Vercel serverless function: /api/xai-proxy
// Forwards the incoming JSON body to xAI's /chat/completions endpoint.
// IMPORTANT: Set XAI_API_KEY in your Vercel Project Environment Variables.

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  const XAI_API_KEY = process.env.XAI_API_KEY;
  const XAI_BASE_URL = process.env.XAI_BASE_URL || 'https://api.x.ai/v1';

  if (!XAI_API_KEY) {
    res.status(500).json({ error: 'Server missing XAI_API_KEY env var' });
    return;
  }

  try {
    const upstreamUrl = `${XAI_BASE_URL}/chat/completions`;
    const upstreamResp = await fetch(upstreamUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${XAI_API_KEY}`
      },
      body: JSON.stringify(req.body)
    });

    const contentType = upstreamResp.headers.get('content-type') || 'application/json';
    const text = await upstreamResp.text();

    res.status(upstreamResp.status).setHeader('content-type', contentType).send(text);
  } catch (err) {
    console.error('Proxy error', err);
    res.status(500).json({ error: 'Proxy request failed', detail: err?.message || String(err) });
  }
}