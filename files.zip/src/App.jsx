import React, { useState, useEffect, useRef } from 'react';
import { Image, Users, Wand2, Film, Loader2, AlertTriangle, Save, FolderOpen, ClipboardCopy, Check } from 'lucide-react';

/**
 * This App is configured to use a serverless proxy by default.
 * For local-only direct API usage (not recommended for production), set in .env.local:
 * VITE_USE_PROXY=false
 * VITE_XAI_API_KEY=your_key_here
 *
 * In production on Vercel, DO NOT set VITE_XAI_API_KEY. Instead set XAI_API_KEY (server env).
 */

const VITE_XAI_API_KEY = import.meta.env.VITE_XAI_API_KEY || "";
const VITE_XAI_BASE_URL = import.meta.env.VITE_XAI_BASE_URL || "https://api.x.ai/v1";
const USE_PROXY = (import.meta.env.VITE_USE_PROXY ?? "true") !== "false"; // default true

const IMAGE_MODEL = "grok-2-128k-image-preview";
const TEXT_MODEL  = "grok-4-128k";

// returns { url, headers }
const getRequestConfig = (path) => {
  if (USE_PROXY) {
    // proxy will forward to the upstream; we POST the full request body to /api/xai-proxy
    return { url: `/api/xai-proxy`, headers: { 'Content-Type': 'application/json' } };
  } else {
    return {
      url: `${VITE_XAI_BASE_URL}${path}`,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${VITE_XAI_API_KEY}`
      }
    };
  }
};

// fetch with exponential backoff
const fetchWithBackoff = async (url, options, retries = 3) => {
  let delay = 1000;
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(url, options);
      if (response.ok) return await response.json();
      if (response.status >= 500 || response.status === 429) {
        console.warn(`API call failed with status ${response.status}. Retrying in ${delay}ms...`);
      } else {
        const err = await response.text();
        throw new Error(`API Error ${response.status}: ${err}`);
      }
    } catch (error) {
      if (i === retries - 1) throw error;
    }
    await new Promise(r => setTimeout(r, delay));
    delay *= 2;
  }
};

const parseImageResponse = (result) => {
  try {
    const content = result?.choices?.[0]?.message?.content;
    if (content && typeof content === 'string') {
      const parsedContent = JSON.parse(content);
      return parsedContent.image || null;
    }
    return null;
  } catch (e) {
    console.error("Error parsing Grok image JSON response:", e);
    return null;
  }
};

const parseTextResponse = (result) => {
  return result?.choices?.[0]?.message?.content || null;
};

const createBorderedBlankImage = (ratio) => {
  const canvas = document.createElement('canvas');
  let width, height;
  const borderWidth = 50;
  if (ratio === '16:9') {
    width = 1600; height = 900;
  } else if (ratio === '9:16') {
    width = 900; height = 1600;
  } else {
    width = 1000; height = 1000;
  }
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'black';
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = 'white';
  ctx.fillRect(borderWidth, borderWidth, width - 2 * borderWidth, height - 2 * borderWidth);
  return canvas.toDataURL('image/png').split(',')[1];
};

const LoadingSpinner = () => (
  <div className="flex justify-center items-center h-full">
    <Loader2 className="w-10 h-10 text-blue-400 animate-spin" />
  </div>
);

const ImagePlaceholder = ({ icon: Icon, text }) => (
  <div className="flex flex-col justify-center items-center w-full h-full min-h-[256px] bg-gray-700/50 rounded-lg border-2 border-dashed border-gray-500 text-gray-400">
    <Icon className="w-16 h-16 mb-2" />
    <span className="text-sm font-medium">{text}</span>
  </div>
);

const getAspectRatioClass = (ratio) => {
  switch (ratio) {
    case '16:9':
      return 'aspect-[16/9]';
    case '9:16':
      return 'aspect-[9/16]';
    default:
      return 'aspect-square';
  }
};

export default function App() {
  const [characterPrompt, setCharacterPrompt] = useState("一個有著藍色長髮的動漫女孩，穿著白色連衣裙，面帶微笑");
  const [scenePrompt, setScenePrompt] = useState("在東京的河邊，靠著欄杆");
  const [videoPrompt, setVideoPrompt] = useState("");
  
  const [characterImageUrl, setCharacterImageUrl] = useState(null);
  const [characterBase64, setCharacterBase64] = useState(null);
  const [finalImageUrl, setFinalImageUrl] = useState(null);
  const [finalImageBase64, setFinalImageBase64] = useState(null);
  const [generatedVideoPrompt, setGeneratedVideoPrompt] = useState(null);
  
  const [loadingStep1, setLoadingStep1] = useState(false);
  const [loadingStep2, setLoadingStep2] = useState(false);
  const [loadingStep3, setLoadingStep3] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [aspectRatio, setAspectRatio] = useState('auto');
  const [generatedAspectRatio, setGeneratedAspectRatio] = useState('auto');
  const [isCopied, setIsCopied] = useState(false);

  const fileInputRef = useRef(null);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const anyLoading = loadingStep1 || loadingStep2 || loadingStep3 || isSaving || isLoading;

  // Step 1: generate character
  const handleGenerateCharacter = async () => {
    setGeneratedAspectRatio(aspectRatio);
    setLoadingStep1(true); 
    setError(null);
    setFinalImageUrl(null); 
    setFinalImageBase64(null);
    setCharacterImageUrl(null);
    setCharacterBase64(null);
    setGeneratedVideoPrompt(null);

    const fullCharacterPrompt = `${characterPrompt}，高品質專業動漫插畫，乾淨的空白背景，請確保人物完整呈現於圖片中`;
    const borderedBlankImageBase64 = createBorderedBlankImage(aspectRatio);
    
    const systemPrompt = "你是一個專業的動漫插畫師，請嚴格按照用戶描述生成圖像。你的輸出必須是單一的 JSON 物件，格式為 {\"image\": \"[base64 encoded image string]\"}，只包含 base64 數據，不要其他文字或說明。";
    
    const payload = {
      model: IMAGE_MODEL,
      messages: [
        { role: "system", content: systemPrompt }, 
        { 
          role: "user", 
          content: [
            { type: "text", text: fullCharacterPrompt },
            { type: "image_url", image_url: { url: `data:image/png;base64,${borderedBlankImageBase64}` }} 
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 4096
    };

    try {
      const { url, headers } = getRequestConfig('/chat/completions');
      const result = await fetchWithBackoff(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload)
      });
      
      const base64Data = parseImageResponse(result);
      if (base64Data) {
        setCharacterBase64(base64Data);
        setCharacterImageUrl(`data:image/png;base64,${base64Data}`);
      } else {
        throw new Error("圖像生成失敗，沒有收到 base64 數據或解析 JSON 失敗。");
      }
    } catch (err) {
      console.error("步驟 1 失敗:", err);
      setError(`產生角色失敗：${err.message}`);
    } finally {
      setLoadingStep1(false);
    }
  };

  // Step 2: scene fusion
  const handleGenerateScene = async () => {
    if (!characterBase64) {
      setError("請先產生一張角色圖片。");
      return;
    }

    setLoadingStep2(true);
    setError(null);
    setFinalImageUrl(null);
    setFinalImageBase64(null);
    setGeneratedVideoPrompt(null);

    const fixedPromptPart = " — while faithfully preserving the illustrated texture and style. Realistic lighting, depth of field, and subtle filming effects are applied to blend the illustration seamlessly with the real environment.";

    const fusionSystemPrompt = "你是一個專業的圖像編輯師，能完美將 2D 動漫角色融合到寫實場景中，保持角色原有的繪畫風格。你的輸出必須是單一的 JSON 物件，格式為 {\"image\": \"[base64 encoded image string]\"}，只包含 base64 數據，不要其他文字或說明。";

    try {
      const { url: textUrl, headers: textHeaders } = getRequestConfig('/chat/completions');
      const refinedResult = await fetchWithBackoff(textUrl, {
        method: 'POST',
        headers: textHeaders,
        body: JSON.stringify({
          model: TEXT_MODEL,
          messages: [
            { role: "system", content: `你是一位專業的提示詞工程師。根據使用者提供的「場景描述」，改寫並擴展這句英文提示：「Placed within a live-action background that matches the illustration’s posture and composition」。只回覆改寫後的英文句子，不要任何說明。` },
            { role: "user", content: `場景描述： ${scenePrompt}` }
          ],
          max_tokens: 256
        })
      });
      
      const refinedPromptPart1 = parseTextResponse(refinedResult) || "";
      if (!refinedPromptPart1) {
        throw new Error("無法從文字模型取得調整後的提示詞。");
      }
      
      const finalCombinedPrompt = refinedPromptPart1 + fixedPromptPart;
      
      const { url: imageUrl, headers: imageHeaders } = getRequestConfig('/chat/completions');
      const imageResult = await fetchWithBackoff(imageUrl, {
        method: 'POST',
        headers: imageHeaders,
        body: JSON.stringify({
          model: IMAGE_MODEL,
          messages: [
            { role: "system", content: fusionSystemPrompt },
            { 
              role: "user", 
              content: [
                { type: "text", text: finalCombinedPrompt },
                { type: "image_url", image_url: { url: `data:image/png;base64,${characterBase64}` }}
              ]
            }
          ],
          response_format: { type: "json_object" },
          max_tokens: 4096
        })
      });

      const finalBase64Data = parseImageResponse(imageResult);
      if (finalBase64Data) {
        setFinalImageBase64(finalBase64Data);
        setFinalImageUrl(`data:image/png;base64,${finalBase64Data}`);
      } else {
        throw new Error("無法從 API 響應中解析最終的融合圖像或解析 JSON 失敗。");
      }

    } catch (err) {
      console.error("步驟 2 失敗:", err);
      setError(`產生融合場景失敗：${err.message}`);
    } finally {
      setLoadingStep2(false);
    }
  };

  // Step 3: generate video prompt
  const handleGenerateVideoPrompt = async () => {
    if (!finalImageBase64) {
      setError("請先完成步驟 2 的圖像融合。");
      return;
    }

    setLoadingStep3(true);
    setError(null);
    setGeneratedVideoPrompt(null);

    try {
      const systemPrompt = `你是一位專業的影片製作提示詞工程師。你的任務是根據提供的圖像和可選的用戶指令，為影片生成模型（如Veo）創建一個詳細的、結構化的英文提示詞。

你的輸出必須遵循以下規則：
1.  **結構化分鏡**: 將提示詞組織成多個分鏡 (Shot)。每個分鏡都應描述一個具體的畫面或動作。
2.  **豐富的鏡頭語言**: 在每個分鏡中，詳細描述鏡頭類型 (例如, close-up, medium shot, wide shot, aerial shot)、攝影機運動 (例如, panning, tilting, tracking shot, dolly zoom)、角度 (例如, low angle, high angle) 和焦點。
3.  **包含音樂描述**: 在提示詞的結尾，建議適合影片氛圍的背景音樂 (BGM) 類型。
4.  **禁止對白與字幕**: 你的輸出絕對不能包含任何形式的角色對白或螢幕上的文字/字幕。
5.  **基於圖像**: 你的描述必須圍繞所提供的圖像內容展開。
6.  **整合用戶指令**: 如果用戶提供了額外的指令，請將其創意融入到你的分鏡設計中。如果用戶指令為空，則完全根據圖像內容自由創作一個短故事。
7.  **風格保持 (Style Consistency)**: 影片的背景是寫實風格 (photorealistic)，但影片中的主角 **必須** 始終保持圖像中原始的 **2D動漫繪畫風格 (2D anime illustration style)**。在描述中強力強調這一點，例如使用 "maintaining her distinct 2D anime art style against the realistic backdrop" 或 "the character, rendered in a clean 2D anime style, moves through the photorealistic world" 等語句。

範例輸出格式:
Shot 1: [鏡頭類型], [攝影機運動]. [場景與角色動作描述].
Shot 2: [鏡頭角度], [鏡頭類型]. [更細節的描述或下一個動作].
...
BGM: [音樂風格或氛圍描述].`;
      
      const userContent = [];
      userContent.push({ type: "image_url", image_url: { url: `data:image/png;base64,${finalImageBase64}` }});
      userContent.push({ type: "text", text: videoPrompt.trim() ? `用戶額外指令：${videoPrompt}` : "無額外指令，請自由發揮一個唯美短篇故事" });

      const payload = {
        model: TEXT_MODEL,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userContent }
        ],
        max_tokens: 2048
      };

      const { url, headers } = getRequestConfig('/chat/completions');
      const result = await fetchWithBackoff(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload)
      });

      const generatedText = parseTextResponse(result);
      if (generatedText) {
        setGeneratedVideoPrompt(generatedText);
      } else {
        throw new Error("無法從 API 響應中解析影片提示詞。");
      }

    } catch (err) {
      console.error("步驟 3 失敗:", err);
      setError(`產生影片提示詞失敗：${err.message}`);
    } finally {
      setLoadingStep3(false);
    }
  };

  // copy prompt
  const handleCopyPrompt = () => {
    if (!generatedVideoPrompt || isCopied) return;

    const fallbackCopy = (text) => {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.top = "0";
      textArea.style.left = "0";
      textArea.style.position = "fixed";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      let success = false;
      try {
        success = document.execCommand('copy');
      } catch (err) {
        console.error('Fallback copy failed', err);
      }

      document.body.removeChild(textArea);
      return success;
    };

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(generatedVideoPrompt).then(() => {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      }).catch(err => {
        console.error('Async clipboard copy failed, trying fallback', err);
        if (fallbackCopy(generatedVideoPrompt)) {
          setIsCopied(true);
          setTimeout(() => setIsCopied(false), 2000);
        } else {
          setError("複製失敗，您的瀏覽器可能不支援此功能。");
        }
      });
    } else {
      if (fallbackCopy(generatedVideoPrompt)) {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      } else {
        setError("複製失敗，您的瀏覽器不支援此功能。");
      }
    }
  };

  // save project
  const handleSaveProject = async () => {
    if (typeof JSZip === 'undefined') {
      setError("JSZip 函式庫尚未載入，請稍後再試。");
      return;
    }
    setIsSaving(true);
    setError(null);
    try {
      const zip = new JSZip();
      const projectData = {
        characterPrompt,
        scenePrompt,
        videoPrompt,
        aspectRatio,
        generatedAspectRatio,
        generatedVideoPrompt,
      };
      zip.file("project.json", JSON.stringify(projectData));

      if (characterBase64) {
        zip.file("character.png", characterBase64, { base64: true });
      }
      if (finalImageBase64) {
        zip.file("final.png", finalImageBase64, { base64: true });
      }

      const content = await zip.generateAsync({ type: "blob" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(content);
      link.download = "project.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

    } catch (err) {
      setError(`儲存專案失敗: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // load project
  const handleLoadProject = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (typeof JSZip === 'undefined') {
      setError("JSZip 函式庫尚未載入，請稍後再試。");
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const zip = await JSZip.loadAsync(file);
      
      const projectFile = zip.file("project.json");
      if (projectFile) {
        const projectData = JSON.parse(await projectFile.async("string"));
        setCharacterPrompt(projectData.characterPrompt || "");
        setScenePrompt(projectData.scenePrompt || "");
        setVideoPrompt(projectData.videoPrompt || "");
        setAspectRatio(projectData.aspectRatio || "auto");
        setGeneratedAspectRatio(projectData.generatedAspectRatio || "auto");
        setGeneratedVideoPrompt(projectData.generatedVideoPrompt || null);
      } else {
        throw new Error("專案檔 (project.json) 不存在。");
      }

      const charImageFile = zip.file("character.png");
      if (charImageFile) {
        const base64 = await charImageFile.async("base64");
        setCharacterBase64(base64);
        setCharacterImageUrl(`data:image/png;base64,${base64}`);
      } else {
        setCharacterBase64(null);
        setCharacterImageUrl(null);
      }

      const finalImageFile = zip.file("final.png");
      if (finalImageFile) {
        const base64 = await finalImageFile.async("base64");
        setFinalImageBase64(base64);
        setFinalImageUrl(`data:image/png;base64,${base64}`);
      } else {
        setFinalImageBase64(null);
        setFinalImageUrl(null);
      }

    } catch (err) {
      setError(`載入專案失敗: ${err.message}`);
    } finally {
      setIsLoading(false);
      if(fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  return (
    <div className="flex flex-col min-h-screen w-full bg-gray-900 text-white p-4 md:p-8 font-sans">
      <header className="mb-6">
        <h1 className="text-3xl font-bold text-center text-blue-300">動漫角色場景融合工具（Grok 版）</h1>
        <p className="text-center text-gray-400 mt-2">使用 xAI Grok 創造角色、融入場景並產生影片提示詞</p>
      </header>

      {error && (
        <div className="mb-4 p-4 bg-red-800/50 border border-red-600 rounded-lg flex items-center text-red-100">
          <AlertTriangle className="w-5 h-5 mr-3 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-6 flex-grow">
        <div className="lg:w-1/3 flex flex-col gap-6">
          <div className="bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-700">
            <h2 className="flex items-center text-xl font-semibold text-gray-300 mb-4">
              專案管理
            </h2>
            <div className="flex gap-4">
              <button
                onClick={handleSaveProject}
                disabled={anyLoading}
                className="flex-1 flex justify-center items-center gap-2 px-4 py-2 bg-gray-600 text-white font-bold rounded-lg shadow-md hover:bg-gray-700 transition-colors duration-200 disabled:bg-gray-600/50 disabled:cursor-not-allowed"
              >
                {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                儲存
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={anyLoading}
                className="flex-1 flex justify-center items-center gap-2 px-4 py-2 bg-gray-600 text-white font-bold rounded-lg shadow-md hover:bg-gray-700 transition-colors duration-200 disabled:bg-gray-600/50 disabled:cursor-not-allowed"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <FolderOpen className="w-5 h-5" />}
                載入
              </button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleLoadProject}
                className="hidden"
                accept=".zip"
              />
            </div>
          </div>

          <div className="bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-700">
            <label className="flex items-center text-xl font-semibold text-blue-300 mb-3">
              <Users className="w-6 h-6 mr-2" />
              步驟 1：產生角色
            </label>
            <p className="text-sm text-gray-400 mb-3">輸入您想要的動漫角色描述。程式將自動要求「空白背景」。</p>
            <textarea
              id="character-prompt"
              rows="4"
              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              value={characterPrompt}
              onChange={(e) => setCharacterPrompt(e.target.value)}
              placeholder="例如：一個戴著眼鏡的棕髮男孩..."
              disabled={anyLoading}
            />

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-400 mb-2">圖片比例</label>
              <div className="flex justify-around gap-2">
                {['auto', '16:9', '9:16'].map((ratio) => (
                  <label key={ratio} className="flex-1">
                    <input
                      type="radio"
                      name="aspectRatio"
                      value={ratio}
                      checked={aspectRatio === ratio}
                      onChange={(e) => setAspectRatio(e.target.value)}
                      className="sr-only"
                      disabled={anyLoading}
                    />
                    <div
                      className={`cursor-pointer text-center p-2 rounded-lg border text-sm font-medium transition-all
                        ${aspectRatio === ratio 
                          ? 'bg-blue-600 border-blue-500 text-white' 
                          : 'bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600'}
                        ${anyLoading ? 'opacity-50 cursor-not-allowed' : ''}
                      `}
                    >
                      {ratio === 'auto' ? '自動 (方形)' : ratio}
                    </div>
                  </label>
                ))}
              </div>
            </div>
            
            <button
              onClick={handleGenerateCharacter}
              disabled={anyLoading}
              className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 transition-colors duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              {loadingStep1 ? <Loader2 className="w-5 h-5 animate-spin" /> : "產生角色"}
            </button>
          </div>

          <div className="bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-700">
            <label className="flex items-center text-xl font-semibold text-green-300 mb-3">
              <Wand2 className="w-6 h-6 mr-2" />
              步驟 2：融合場景
            </label>
            <p className="text-sm text-gray-400 mb-3">輸入角色所在的真實場景描述。必須先產生角色。</p>
            <textarea
              id="scene-prompt"
              rows="3"
              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-green-500 focus:outline-none"
              value={scenePrompt}
              onChange={(e) => setScenePrompt(e.target.value)}
              placeholder="例如：在下雨的街道上..."
              disabled={!characterBase64 || anyLoading}
            />
            <button
              onClick={handleGenerateScene}
              disabled={!characterBase64 || anyLoading}
              className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-green-600 text-white font-bold rounded-lg shadow-md hover:bg-green-700 transition-colors duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              {loadingStep2 ? <Loader2 className="w-5 h-5 animate-spin" /> : "融合至場景"}
            </button>
          </div>

          <div className="bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-700">
            <label className="flex items-center text-xl font-semibold text-purple-300 mb-3">
              <Film className="w-6 h-6 mr-2" />
              步驟 3：產生影片提示詞
            </label>
            <p className="text-sm text-gray-400 mb-3">可選填關於影片的額外指令，或留白由 AI 自動產生。必須先完成場景融合。</p>
            <textarea
              id="video-prompt"
              rows="3"
              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:outline-none"
              value={videoPrompt}
              onChange={(e) => setVideoPrompt(e.target.value)}
              placeholder="例如：鏡頭拉遠，顯示整個城市的夜景"
              disabled={!finalImageBase64 || anyLoading}
            />
            <button
              onClick={handleGenerateVideoPrompt}
              disabled={!finalImageBase64 || anyLoading}
              className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-purple-600 text-white font-bold rounded-lg shadow-md hover:bg-purple-700 transition-colors duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              {loadingStep3 ? <Loader2 className="w-5 h-5 animate-spin" /> : "產生影片提示詞"}
            </button>
          </div>
        </div>

        <div className="lg:w-2/3 flex flex-col gap-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gray-800 p-4 rounded-lg shadow-lg border border-gray-700 flex flex-col">
              <h3 className="text-lg font-semibold text-center text-gray-300 mb-3">角色 (空白背景)</h3>
              <div className={`flex-grow flex items-center justify-center bg-black/20 rounded-lg overflow-hidden ${getAspectRatioClass(generatedAspectRatio)}`}>
                {loadingStep1 || isLoading ? <LoadingSpinner /> : characterImageUrl ? <img src={characterImageUrl} alt="生成的角色" className="object-contain w-full h-full" /> : <ImagePlaceholder icon={Users} text="等待產生角色" />}
              </div>
            </div>

            <div className="bg-gray-800 p-4 rounded-lg shadow-lg border border-gray-700 flex flex-col">
              <h3 className="text-lg font-semibold text-center text-gray-300 mb-3">最終融合圖片</h3>
              <div className={`flex-grow flex items-center justify-center bg-black/20 rounded-lg overflow-hidden ${getAspectRatioClass(generatedAspectRatio)}`}>
                {loadingStep2 || isLoading ? <LoadingSpinner /> : finalImageUrl ? <img src={finalImageUrl} alt="最終融合場景" className="object-contain w-full h-full" /> : <ImagePlaceholder icon={Wand2} text="等待融合場景" />}
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg shadow-lg border border-gray-700 flex flex-col flex-grow">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-lg font-semibold text-center text-gray-300">產生的影片提示詞</h3>
              {generatedVideoPrompt && (
                <button 
                  onClick={handleCopyPrompt}
                  className={`flex items-center gap-2 px-3 py-1 text-sm rounded-md transition-colors ${isCopied ? 'bg-green-600 text-white' : 'bg-gray-600 hover:bg-gray-500 text-gray-200'}`}
                  disabled={isCopied}
                >
                  {isCopied ? <Check className="w-4 h-4" /> : <ClipboardCopy className="w-4 h-4" />}
                  {isCopied ? '已複製' : '複製'}
                </button>
              )}
            </div>
            <div className="flex-grow flex items-center justify-center bg-black/20 rounded-lg p-4 min-h-[150px]">
              {loadingStep3 || isLoading ? <LoadingSpinner /> : generatedVideoPrompt ? (
                <pre className="w-full h-full text-sm text-left whitespace-pre-wrap font-mono bg-transparent p-2 rounded overflow-auto">{generatedVideoPrompt}</pre>
              ) : (
                <ImagePlaceholder icon={Film} text="等待產生影片提示詞" />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}